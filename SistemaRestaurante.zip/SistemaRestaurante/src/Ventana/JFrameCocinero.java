package Ventana;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class JFrameCocinero extends JFrame {

    private JTable tablaPedidos, tablaDetallePedido;
    private DefaultTableModel modeloPedidos, modeloDetalle;
    private JButton btnActualizarEstado,btnCerrarSesion;

    private int pedidoSeleccionado = -1;

    // Estados posibles para avanzar
    private final String[] estadosValidos = {"Pendiente", "En preparación", "Servido"};

    public JFrameCocinero() {
        setTitle("Panel Cocinero - Gestión de Pedidos");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel superior con tabla de pedidos
        modeloPedidos = new DefaultTableModel(new String[]{"ID Pedido", "Mesa", "Estado"}, 0) {
            // Que no se pueda editar directamente en tabla
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaPedidos = new JTable(modeloPedidos);
        JScrollPane scrollPedidos = new JScrollPane(tablaPedidos);
        scrollPedidos.setPreferredSize(new Dimension(780, 200));

        // Panel central con tabla detalle del pedido seleccionado
        modeloDetalle = new DefaultTableModel(new String[]{"Platillo", "Cantidad"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaDetallePedido = new JTable(modeloDetalle);
        JScrollPane scrollDetalle = new JScrollPane(tablaDetallePedido);
        scrollDetalle.setPreferredSize(new Dimension(780, 300));

        // Panel botones para actualizar estado
        btnActualizarEstado = new JButton("Avanzar Estado");

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnActualizarEstado);

        add(scrollPedidos, BorderLayout.NORTH);
        add(scrollDetalle, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        cargarPedidos();

        // Listener para seleccionar pedido y cargar detalles
        tablaPedidos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int fila = tablaPedidos.getSelectedRow();
                if (fila >= 0) {
                    pedidoSeleccionado = (int) modeloPedidos.getValueAt(fila, 0);
                    cargarDetallePedido(pedidoSeleccionado);
                }
            }
        });

        btnActualizarEstado.addActionListener(e -> {
            if (pedidoSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione un pedido primero.");
                return;
            }
            try {
                avanzarEstadoPedido(pedidoSeleccionado);
                cargarPedidos();
                cargarDetallePedido(pedidoSeleccionado);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al actualizar estado: " + ex.getMessage());
            }
        });
    }

    private void cargarPedidos() {
        modeloPedidos.setRowCount(0);
        String sql = "SELECT id, mesa, estado FROM pedidos WHERE estado IN ('Pendiente', 'En preparación', 'Servido') ORDER BY id DESC";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                modeloPedidos.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("mesa"),
                        rs.getString("estado")
                });
            }
            pedidoSeleccionado = -1;
            modeloDetalle.setRowCount(0);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar pedidos: " + e.getMessage());
        }
    }

    private void cargarDetallePedido(int idPedido) {
        modeloDetalle.setRowCount(0);
        String sql = "SELECT p.nombre, dp.cantidad FROM detalles_pedido dp JOIN platillos p ON dp.id_platillo = p.id WHERE dp.id_pedido = ?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idPedido);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                modeloDetalle.addRow(new Object[]{
                        rs.getString("nombre"),
                        rs.getInt("cantidad")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar detalles del pedido: " + e.getMessage());
        }
    }

    private void avanzarEstadoPedido(int idPedido) throws SQLException {
        String estadoActual = null;
        String sqlEstado = "SELECT estado FROM pedidos WHERE id = ?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sqlEstado)) {
            ps.setInt(1, idPedido);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                estadoActual = rs.getString("estado");
            } else {
                throw new SQLException("Pedido no encontrado.");
            }
        }

        // Obtener el siguiente estado si existe y no sea "Pagado"
        int idx = -1;
        for (int i = 0; i < estadosValidos.length; i++) {
            if (estadosValidos[i].equalsIgnoreCase(estadoActual)) {
                idx = i;
                break;
            }
        }
        if (idx == -1) {
            throw new SQLException("Estado actual inválido o no modificable.");
        }
        if (idx == estadosValidos.length - 1) {
            JOptionPane.showMessageDialog(this, "El pedido ya está en estado '" + estadosValidos[idx] + "' y no se puede avanzar más.");
            return;
        }
        String nuevoEstado = estadosValidos[idx + 1];

        // Actualizar estado en BD
        try (Connection con = ConexionBD.conectar();
             PreparedStatement psUpd = con.prepareStatement("UPDATE pedidos SET estado = ? WHERE id = ?")) {
            psUpd.setString(1, nuevoEstado);
            psUpd.setInt(2, idPedido);
            psUpd.executeUpdate();
            JOptionPane.showMessageDialog(this, "Estado actualizado a: " + nuevoEstado);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new JFrameCocinero().setVisible(true));
    }
}
